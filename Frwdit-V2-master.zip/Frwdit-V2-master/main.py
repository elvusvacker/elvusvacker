from bot import Bot

app = Bot()
app.run()
