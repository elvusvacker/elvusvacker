# 📠 Auto Forward V2
A Simple Bot can copy any media to a private channel provided!
Without Admin Permission in FROM_CHANNEL
Only Give Permission In your Telegram Personal Channel

```
Please fork this repository then give star
Made with Python3 and Pyrogram Library
(C) @DarkzzAngel
Copyright permission under GNU GENERAL PUBLIC LICENSE
```

## Working:
- Add The Bot to Your To channel as admin
- Join User in From channel (No need Admin Permission)
- To channel id = @Username
- For the above, You need to give a valid channel Id starting with '-100' in the var "To Channel_ID"

## USAGE
```
#commmands
/start - alive
/help - more help
/about - about me
/run - forward starting
/restart - restart server

#Variables
BOT_TOKEN - Your Bot Token (Obtain it from @botfather)
API_ID - Your APP ID (Obtain it from my.telegram.org)
API_HASH - Your API Hash (Obtain it from my.telegram.org)
OWNER_ID - Your telegram id
CAPTION - If you want to add a caption to the forwarded file, enter it here
SESSION - Pyrogram string Seccion - https://replit.com/@JijinR/PyroSessionString?v=1
```

### Deploying on Heroku:

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://youtu.be/B6jQGOJDVi0)

### Deploying on Railway:

[![Deploy on Railway](https://railway.app/button.svg)](https://youtu.be/B6jQGOJDVi0)

### Legendary Way:
#### On Linux Or VPS:

- Add The Bot to Your To channel as admin
- Join User in From channel (No need Admin Permission)
- Finally, run the following

```
virtualenv -p python3 venv
. ./venv/bin/activate
pip3 install -r requirements.txt
python3 main.py
```

### Credits

* [Pyrogram](https://github.com/pyrogram/pyrogram)
* `Special Thanks Dump Group Members`🤣
